﻿namespace SAS.ViewModels
{
    public class DetailsViewModel
    {
        public UserViewModel? user { get; set; }
        public UserDetailsViewModel? details { get; set; }
    }
}
