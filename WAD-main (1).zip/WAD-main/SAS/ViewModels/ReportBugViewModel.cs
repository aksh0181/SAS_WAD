﻿namespace SAS.ViewModels
{
    public class ReportBugViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
        public string StatusMessage { get; set; }
    }

}
